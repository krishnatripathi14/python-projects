hour = float(input("Enter hour: "))
rate = float(input("Enter rate: "))
pay = (hour * rate)
print(round(pay, 2))

