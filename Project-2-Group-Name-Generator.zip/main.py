print("Welcome to the group name generator:")
color = input("what's your favorite color? ")
animal = input("what's your favorite animal? ")
print(f"your group name could be {color} {animal}s") 