# Group Name Project 

## Instruction

1. Create a greeting for your program.
2. Ask the user for their favorite color.
3. Ask the user for their favotire animal.
4. Combine the name of their favorite color and animal and show them their group name.

## Examples

```
Welcome to the Group Name Generator.
What's your favorite color?
> Red
What's your favorite animal?
> Lion
Your group name could be Red Lions
```


# Solution

[https://replit.com/@AppMillers/Project-2-Group-Name-Generator-Solution](https://replit.com/@AppMillers/Project-2-Group-Name-Generator-Solution)