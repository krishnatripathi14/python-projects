name = input("hey what is your name? ")
print(f'Hello {name}.\nWelcome to the python')