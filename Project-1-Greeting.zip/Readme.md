# Greeting Project 

## Instruction

Write a program that uses input to prompt a user for their name and then welcomes them.

## Input

```
Elshad
```

## Output
```
Hello Elshad.
Wellcome to the Python
```


# Solution

[https://replit.com/@AppMillers/Project-1-Greeting-Solution](https://replit.com/@AppMillers/Project-1-Greeting-Solution)