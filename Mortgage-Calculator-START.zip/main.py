print("Welcome to mortgage calculator!")
salary = int(input("what is your salary? "))

if salary > 2000:
  print("you are eligible for mortgage!")
else:
  print("you are not eligible for mortgage!")