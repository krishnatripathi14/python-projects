temperatureCel = input("Enter the temperature in celsius: ")

temperatureFah = (float(temperatureCel) * 9/5) + 32

print(f"{temperatureCel} celsius = {temperatureFah} fahrenheit")